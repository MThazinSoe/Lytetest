using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CalendarAPI.Helper;
using CalendarAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace CalendarAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CalendarController : ControllerBase
    {
        
        private readonly ILogger<CalendarController> _logger;

        public CalendarController(ILogger<CalendarController> logger)
        {
            _logger = logger;
        }
        
        [HttpGet]
        public IEnumerable<GoogleCalendar> Get()
        {
            List<GoogleCalendar> CalendarList = CalendarHelper.ListGoogleCalendar();
            return CalendarList.ToArray();
        }

        [HttpPost]
        public async Task<IActionResult> CreateGoogleCalendar([FromBody] GoogleCalendar request)
        {
            return Ok(await CalendarHelper.CreateGoogleCalendar(request));
        }


        [HttpPut]
        public async Task<IActionResult> UpdateGoogleCalendar(string id,[FromBody] GoogleCalendar request)
        {
            return Ok(await CalendarHelper.UpdateGoogleCalendar(request,id));
        }
    }
}