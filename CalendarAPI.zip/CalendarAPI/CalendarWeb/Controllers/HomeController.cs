﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CalendarWeb.Models;
using CalendarWeb.Helper;
using System.Net.Http;
using Newtonsoft.Json;

namespace CalendarWeb.Controllers
{
    public class HomeController : Controller
    {

        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        CalendarAPI _api = new CalendarAPI();

        public async Task<IActionResult> Index()
        {

            List<GoogleCalendar> events = new List<GoogleCalendar>();
            HttpClient client = _api.Initial();
            HttpResponseMessage res = await client.GetAsync("api/Calendar");
            if(res.IsSuccessStatusCode)
            {
                var results = res.Content.ReadAsStringAsync().Result;
                events = JsonConvert.DeserializeObject<List<GoogleCalendar>>(results);
            }
             return View(events);

          }



        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create( GoogleCalendar calendarevent)
        {
            HttpClient client = _api.Initial();
            var postTask = client.PostAsJsonAsync<GoogleCalendar>("api/Calendar", calendarevent);
            postTask.Wait();

            var result = postTask.Result;
            if ( result.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            return View();
        }

        public async Task<IActionResult> Delete( string ID)
        {
            var GoogleCalendar = new GoogleCalendar();
            HttpClient client = _api.Initial();
            HttpResponseMessage res = await client.DeleteAsync($"api/Calendar/{ID}");
            return RedirectToAction("Index");
        }
    }
}
